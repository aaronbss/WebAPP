select*from Class;
Insert into Class(CID,Class_Name) values('10','Grade 10');
