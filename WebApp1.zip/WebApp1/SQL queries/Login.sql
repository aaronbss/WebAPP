select *from Login;
insert into Login(Name,email,password,type) values('PadmaRaj','Padma@gmail.com','Padma101','Admin');

SELECT * FROM Login WHERE Type = 'student' AND email = 'aaron@gmail.com' AND password = 'Anthony10c1997' or select *from Student;

update Login
SET Name = 'Aaron Anthony'