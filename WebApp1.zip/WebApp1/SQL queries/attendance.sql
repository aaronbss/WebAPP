select *from Attendance;
insert into Attendance(SID,TID,Time_Stamp) values('5','2','2020-01-30');
ALTER TABLE Attendance ADD Time_Stamp Date;
use student;
	SELECT s.SID, s.SRoll_No, s.Name , a.Time_Stamp, t.TSubject FROM Student s INNER JOIN Attendance a INNER JOIN Teacher t ON a.SID WHERE t.TID = a.TID; 

insert into Attendance(SID,TID,Time_Stamp) values('5','2','2020-01-30');

select  s.SID FROM Student s WHERE s.SRoll_No = '10518734';
select  SID FROM Student   WHERE SRoll_No = '10518735'
select distinct t.TID FROM Teacher t INNER JOIN Attendance ON t.TID WHERE TSubject = 'Research Methodology'
update a FROM Attendance a 
LEFT JOIN Student s ON s.SID = a.SID
LEFT JOIN Teacher t ON t.TID = a.TID
WHERE s.SRoll_No ='10518734' AND t.TSubject ='Python Web Dev' AND a.Time_Stamp = '2020-01-01'

UPDATE Attendance 
SET TID = '3'
 WHERE s.SID, s.SRoll_No, s.Name , a.Time_Stamp FROM Student s INNER JOIN Attendance a ON a.SID

SELECT s.SID,s.SRoll_No,s.Name, COUNT(*) as Total_Lectures_Attended FROM Student s 
INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID, '%')   GROUP BY s.SID;
AND Teacher t ON s.SID = e.SID AND s.SRoll_No = '10518734' AND t.TSubject = 'Python Web Dev' 

SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID) WHERE e.TID = (select TID from Teacher where TSubject='Python Web Dev') AND s.SRoll_No = 10518734 GROUP BY s.SID


SELECT s.SID, s.SRoll_No, s.Name, , INT_TEST_ONE + INT_TEST_TWO 
AS SUM FROM TABLE

