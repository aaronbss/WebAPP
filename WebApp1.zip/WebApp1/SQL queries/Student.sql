select *from Student;
insert into Student(SRoll_No,Name,DOB,Address,Phone,Class) values('10518738', 'Santosh Mishra','1995-01-22','69, Threecum Towers, Banggang Road','089469869','Grade 10');
ALTER TABLE SID AUTO_INCREMENT = 4
delete from Student
Where Name ="Aaron Anthony";

update Student
SET SID =5
where name = "Santosh Mishra";

ALTER TABLE Student
DROP PRIMARY KEY,
CHANGE SID SID int(11);


LOAD XML LOCAL INFILE 'C:/Users/aaron/OneDrive/Desktop/Backup webapp/student_data.xml' 
into TABLE Student ROWS IDENTIFIED BY '<Students>';


SET GLOBAL local_infile = 1
LOAD DATA LOCAL INFILE 'C:/Users/aaron/OneDrive/Desktop/Backup webapp/student_data.xml' INTO TABLE Student;

LOAD XML LOCAL INFILE '\student_data'
    INTO TABLE Student
    ROWS IDENTIFIED BY '<Students>';
    
show global variables like 'local_infile'; 

