insert into student(Sname) values("Aaron");
 show databaSes;
 select *from student;
 use student
 drop table student;
 show tAbles;
 
 insert into Login(Name,email,password,type) values('','aaron@gmail.com','Anthony10c1997','Teacher');
 select *from Login;
delete from Login
Where Name = "";
use student;
select *from Login WHERE Type = "student" AND email  = "aaron@gmail.com";
show tables;

SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID, '%') WHERE e.TID = (select TID from Teacher where TSubject='Python Web Dev') GROUP BY s.SID
 
LOAD XML LOCAL INFILE 'C:\Users\aaron\OneDrive\Desktop\Backup webapp\student_data.xml' 
INTO TABLE Student(); 

show global variables like 'local_infile'
select *from stud;
LOAD DATA LOCAL INFILE 'student_data.xml' into table Student;

