select *from Teacher;
insert into Teacher(Tname,TSubject,CID) values ('Amir', 'Research Methodology', '10');

delete from Teacher
Where TName = "Amir";	
SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID, '%') WHERE e.TID = (select TID from Teacher where TSubject='Research Methodology') GROUP BY s.SID;
