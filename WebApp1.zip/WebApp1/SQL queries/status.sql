insert into status(TID,Time_Stamp) values('2','2020-01-30');
select *from status;
SELECT t.TSubject,t.TName,t.TID, COUNT(*) Lectures_Conducted FROM Teacher t 
INNER JOIN status s ON s.TID LIKE CONCAT(t.TID, '%') group by s.TID;
UPDATE status
SET TID = '3'
WHERE TID = 2;