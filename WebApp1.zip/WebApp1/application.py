from flask import Flask, render_template, request, flash, session, redirect, url_for, json
import pymysql
from pymysql import cursors
import os
import pygal
from flask_socketio import SocketIO
from pusher import pusher
from flask_cors import CORS

application = Flask(__name__)
cors = CORS(application)
application.config['CORS_HEADERS'] = 'Content-Type'
# configure pusher object
pusher = pusher.Pusher(app_id='961890', key='2b771e1e2fb96873e45f',secret='2aeed76b9adcf73332f4', cluster='eu', ssl=True)


host = "attendance.cvx83klzssh3.us-east-1.rds.amazonaws.com"
port = 3306
dbname = "student"
user = "root"
passwod = "Anthony10c1997$"

application.config['SECRET_KEY'] = os.urandom(24)

conn = pymysql.connect(host=host, user=user, port=port, password=passwod, db=dbname, cursorclass=pymysql.cursors.DictCursor)
conn1 = pymysql.connect(host=host, user=user, port=port, password=passwod, db=dbname)

cursor1 = conn.cursor(cursors.DictCursor)
cursor = conn1.cursor()


@application.route('/', methods=['GET', 'POST'])
def home():
    return render_template('index.html')


@application.route('/student_log', methods=['GET', 'POST'])
def student():
    c = 'student'
    a = 'student_login.html'
    p = 'stud_main'
    return login(c, a, p)


@application.route('/teacher_log', methods=['GET', 'POST'])
def teacher():
    d = 'Teacher'
    b = 'teacher_login.html'
    q = 'teach_main'
    return login(d, b, q)


@application.route('/admin_log', methods=['GET', 'POST'])
def admin():
    f = 'Admin'
    t = 'admin_login.html'
    j = 'admin_main'
    return login(f, t, j)


@application.route('/student', methods=['GET', 'POST'])
def stud_main():
    if 'loggedin' in session:
        if request.method == 'POST':
            data1 = session['SRoll_No']
            print(data1)
            if request.form.get('Python Web Dev') == 'Python Web Dev':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID) WHERE e.TID = (select TID from Teacher where TSubject='Python Web Dev') AND s.SRoll_No = %s", data1)
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Research Methodology') == 'Research Methodology':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID) WHERE e.TID = (select TID from Teacher where TSubject='Research Methodology') AND s.SRoll_No=%s", data1)
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Enterprise Resource Planning') == 'Enterprise Resource Planning':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID) WHERE e.TID = (select TID from Teacher where TSubject='Enterprise Resource Planning') AND s.SRoll_No=%s", data1)
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Data Analytics') == 'Data Analytics':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID) WHERE e.TID = (select TID from Teacher where TSubject='Data Analytics') AND s.SRoll_No=%s", data1)
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Total Attendance') == 'Total Attendance':
                cursor.execute("SELECT t.TSubject,t.TName,t.TID, COUNT(*) Lectures_Conducted FROM Teacher t INNER JOIN status s ON s.TID LIKE CONCAT(t.TID, '%') group by s.TID;")
                data = cursor.fetchall()
                return render_template('tot_att.html', data=data)
    return render_template('student.html')


@application.route('/Admin', methods=['GET', 'POST'])
def admin_main():
    if 'loggedin' in session:
        if request.method == 'POST':
            if request.form.get('Add New Teacher') == 'Add New Teacher':
                print("Admin in")
    return render_template('admin.html')


@application.route('/Teacher', methods=['GET', 'POST'])
def teach_main():
    if 'loggedin' in session:
        if request.method == 'POST':
            if request.form.get('Att') == 'Att':
                print("Teacher in")
                return redirect(url_for('teach_stud'))
            elif request.form.get('Mod') == 'Mod':
                return redirect(url_for('teach_mod'))
            elif request.form.get('raise') == 'raise':
                return redirect((url_for('teach_admin')))
    return render_template('teacher.html')


@application.route('/teacher_student', methods=['GET', 'POST'])
def teach_stud():
    if 'loggedin' in session:
        if request.method == 'POST':
            if request.form.get('Python Web Dev') == 'Python Web Dev':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID, '%') WHERE e.TID = (select TID from Teacher where TSubject='Python Web Dev')  GROUP BY s.SID")
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Research Methodology') == 'Research Methodology':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID, '%') WHERE e.TID = (select TID from Teacher where TSubject='Research Methodology') GROUP BY s.SID")
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Enterprise Resource Planning') == 'Enterprise Resource Planning':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID, '%') WHERE e.TID = (select TID from Teacher where TSubject='Enterprise Resource Planning') GROUP BY s.SID")
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Data Analytics') == 'Data Analytics':
                cursor.execute("SELECT s.SID,s.SRoll_No,s.Name,COUNT(*) Lectures_Attended FROM Student s INNER JOIN Attendance e ON e.SID LIKE CONCAT(s.SID, '%') WHERE e.TID = (select TID from Teacher where TSubject='Data Analytics') GROUP BY s.SID")
                data = cursor.fetchall()
                return render_template('attendance.html', data=data)
            elif request.form.get('Total Lectures Conducted') == 'Total Lectures Conducted':
                cursor.execute("SELECT t.TSubject,t.TName,t.TID, COUNT(*) Lectures_Conducted FROM Teacher t INNER JOIN status s ON s.TID LIKE CONCAT(t.TID, '%') group by s.TID;")
                data = cursor.fetchall()
                return render_template('tot_att.html', data=data)
    return render_template('teacher2.html')


@application.route('/teach_modify', methods=['GET', 'POST'])
def teach_mod():
    if 'loggedin' in session:
        if request.method == 'POST':
            if request.form.get('sub') == 'sub':
                    subject = request.form.get('subjects')
                    roll = request.form.get('roll')
                    date = request.form.get('date')
                    print(roll, date, subject)
                    if request.form.get('update') == 'delete':
                        cursor.execute("delete a FROM Attendance a LEFT JOIN Student s ON s.SID = a.SID LEFT JOIN Teacher t ON t.TID = a.TID WHERE s.SRoll_No =%s AND t.TSubject =%s AND a.Time_Stamp = %s",(roll,subject,date))
                        cursor.execute("Select *from Attendance")
                        data = cursor.fetchall()
                        return render_template('stud_mod.html', data=data)
                    elif request.form.get('update') == 'add':
                        cursor.execute("select  SID FROM Student WHERE SRoll_No =%s", roll)
                        sid = cursor.fetchone()
                        print(sid)
                        cursor.execute("select TID FROM Teacher  WHERE TSubject =%s",subject)
                        tid = cursor.fetchone()
                        print(tid)
                        cursor.execute("insert into Attendance(SID,TID,Time_Stamp) values(%s,%s,%s)", (sid, tid, date))
                        data = cursor.fetchall()
                        print(data)
                        cursor.execute("select *from Attendance")
                        data1 = cursor.fetchall()
                        return render_template('stud_mod.html', data=data1, )
    return render_template('stud_att.html')


@application.route('/teach_admin', methods=['GET','POST'])
def teach_admin():
    if 'loggedin' in session:
        if request.method == 'POST':
            if request.form.get('raise') == 'raise':
                return render_template('teach_admin.html')
    return render_template('teacher.html')


@application.route('/new/guest', methods=['POST'])
def guestUser():
    data = request.json
    pusher.trigger(u'general-channel', u'new-guest-details', {'name': data['name'], 'email': data['email']})
    return json.dumps(data)


@application.route("/pusher/auth", methods=['POST'])
def pusher_authentication():
    auth = pusher.authenticate(channel=request.form['channel_name'], socket_id=request.form['socket_id'])
    return json.dumps(auth)


def login(e, x, y):
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']
        if(cursor1.execute("SELECT * FROM Login WHERE Type = %s AND email = %s AND password =%s", (e, email, password))== True):
            data = cursor1.fetchone()
            if data:
                session['loggedin'] = True
                session['email'] = data['email']
                return redirect(url_for(y))
        elif (cursor1.execute("Select *from Student WHERE SRoll_No = %s AND Phone = %s", (email, password))== True):
            if(e == 'student'):
                data = cursor1.fetchone()
                if data:
                    session['loggedin'] = True
                    session['SRoll_No'] = data['SRoll_No']
                    return redirect(url_for(y))
    return render_template(x)


@application.route('/logout')
def logout():
    session.pop('email', None)
    session.pop('SRoll_No', None)
    return redirect('/')


if __name__ == '__main__':
    application.run(debug=True, use_reloader=True)


